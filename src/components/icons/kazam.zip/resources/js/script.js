function runAjax() {
    jQuery('.regenDone').hide();
    jQuery('.regen').show();
    jQuery('#kz_overlay').show();
    jQuery('#kz_ajax').fadeIn();
    jQuery.ajax({
        url: 'index.php?option=com_ajax&task=runAjax&format=raw',
        dataType: 'json',
        cache: false,
        success: function(json) {
            if(json.count == '0') {
                jQuery('.regen').hide();
                jQuery('.regenDone').fadeIn();
            } else {
                jQuery('#kz_count').html(json.count);
                runAjax(); 
            }
        }
    });
}

function cancelAjax() {
    jQuery.ajax({
        url: 'index.php?option=com_ajax&task=cancelAjax&format=raw',
        dataType: 'json',
        cache: false,
        success: function(json) {
            location.reload();
        }
    });
}

jQuery(document).ready(function() {
    jQuery('#kz_cancel').click(function() {
        cancelAjax();
    });
    jQuery('#kz_continue').click(function() {
        location.reload();
    });
})