<?php
/* -------------------------------------------
Component: plg_KAZAAM!
Author: Barnaby Dixon
Email: barnaby@php-web-design.com
Copywrite: Copywrite (C) 2012 Barnaby Dixon. All Rights Reserved.
License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
---------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.form.formfield');

class JFormFieldRegenInput extends JFormField {

    public function getInput() {
        $kpl = $this->checkKpl();
        $value = ($kpl === FALSE) ? '1' : '0';
        $ret = '<input name="jform[params][regen]" id="jform_params_regen" value="'.$value.'" type="hidden" value="1"><style>#jform_params_regen-lbl { display:none} </style>';
        if($kpl !== FALSE) $ret .= $kpl;
        return $ret;
    }

    function checkKpl() {
        if(!file_exists(JPATH_ADMINISTRATOR.'/components/com_kazaam/classes/kazaam.class.php')) return FALSE;
        $ret = "<style>.control-group { display: none} </style>";
        return $ret;
    }
}