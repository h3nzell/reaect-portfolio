<?php
/* -------------------------------------------
Component: plg_KAZAAM!
Author: Barnaby Dixon
Email: barnaby@php-web-design.com
Copywrite: Copywrite (C) 2012 Barnaby Dixon. All Rights Reserved.
License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
---------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.form.formfield');

class JFormFieldCategoryList extends JFormField {

    public function getInput() {

        $db = JFactory::getDBO();
        
        //GET THE AVAILABLE CATEGORIES
        $query = "SELECT c.id, c.parent_id, c.title, c.level FROM #__categories AS c WHERE c.extension = 'com_content' ORDER BY c.parent_id ASC, c.lft, c.id";
        $db->setQuery($query);
        $c = $db->loadAssocList();
        if(count($c)>0) foreach($c as $d) {
            $categories[$d['parent_id']][] = $d;
        } else {
            $categories = array(
                array(
                    'id' => 0,
                    'title' => 'Please define your categories'
                )
            );
        }
        if ($db->getErrorNum())	{
            echo $db->stderr();
            return false;
        }
        unset($c);
        
        $options = $this->showCats($categories,$this->value);
        $ret = "<select id='{$this->id}' name='{$this->name}[]' multiple='multiple' style='width:200px;height: 300px;'>{$options}</select>";
        
        return $ret;
    }

    function showCats($cats, $selcats, $parent = 1, $lvl = 0, $j=0) {
        if(!is_array($cats[$parent])) return false;
        if(!is_array($selcats)) $selcats = array();
        $offset = $lvl * 5;
        if(!isset($ret)) $ret = '';
        foreach($cats[$parent] as $a=>$b) {
        $ret .= "<option value='{$b['id']}'";
        if(in_array($b['id'], $selcats)) $ret .= " selected='selected' ";
        $ret .= ">";
        if($offset > 0) for($i=0; $i<=$offset; $i++) $ret .= "&nbsp;";
        $ret .= "{$b['title']}</option>";
        $j++;
        if(@is_array($cats[$b['id']])) $ret .= $this->showCats($cats, $selcats, $b['id'], $b['level'], $j);
        }
        return $ret;
    }
}