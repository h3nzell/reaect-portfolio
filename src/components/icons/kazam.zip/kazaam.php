<?php
/* -------------------------------------------
Component: plg_KAZAAM!
Author: Barnaby Dixon
Email: barnaby@php-web-design.com
Copywrite: Copywrite (C) 2012 Barnaby Dixon. All Rights Reserved.
License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
---------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$time = time();

class plgSystemKazaam extends JPlugin {
    
    private $triggers = array(
        'categories',
        'category',
        'articles',
        'article'
    );
    private $actions = array(
        'save',
        'apply',
        'publish',
        'unpublish',
        'archive',
        'featured',
        'trash',
        'batch',
        'rebuild',
        'save2copy'
    );
    private $myparams = array(
        'name' => 'Kazaam!',
        'alias' => 'kazaam',
        'regen' => 0,
        'categories' => array(),
        'cats' => 1,
        'subcats' => 1,
        'arts' => 1,
        'category_layout' => 'blog',
        'language' => '*',
        'access' => '1',
        'status' => '1',
        'type' => '0',
        'params' => array()
    );
    private $table = '#__kazaam_regen';
    private $config;
    private $kpl = 0;
    
    private static $_order = 0;

    function __construct(&$subject, $params) {
        parent::__construct($subject, $params);
    }
    
    function onAfterRoute() {
        if($this->checkKpl() === TRUE) {
            if(!$this->checkTask()) {
                $ret = (int) $this->regenKplTasks();
                $this->saveJson($ret);
            }
        } else if(!$this->checkTask()) {
            $ret = (int) $this->regenTasks();
            $this->saveJson($ret);
        }
    }
    
    private function doAjax() {
        $db = JFactory::getDBO();
        $table = $db->quoteName('#__kazaam_regen');
        $query = "SELECT COUNT(*) FROM {$table}";
        $db->setQuery($query);
        $count = $db->loadResult();
        if($count > 0) {
            echo '<link rel="stylesheet" href="../plugins/system/kazaam/resources/css/style.css" type="text/css" />';
            echo '<script src="../media/jui/js/jquery.min.js" type="text/javascript"></script>';
            echo '<script src="../plugins/system/kazaam/resources/js/script.js" type="text/javascript"></script>';
            echo '<div id="kz_overlay">�</div><div id="kz_ajax"><div id="kz_ajax_inner"><img id="kz_ajax_logo" src="../plugins/system/kazaam/kazaam/kazaam-logo.png"  /><h3>Your menu is being regenerated</h3><div style="display: block;" id="regen" class="processdiv regen"><span class="ajax"></span><span id="kz_count">'.$count.'</span> items remaining</div><div id="regen_msg" class="regen"><p>Please wait for the menu to be regenerated.</p><p><div id="kz_cancel">CANCEL</div></p></div><div  id="regenDone" class="processdiv regenDone"><span class="done"></span>Your menu has been regenerated</div><div id="regen_done_msg" class="regenDone"><div id="kz_continue">CONTINUE</div></div></div></div>';
            echo '<script>runAjax();</script>';
        }
    }
    
    private function saveJson($count) {
        $count = (int) $count;
        $format = JRequest::getCmd('format');
        $task = JRequest::getCmd('task');
        $option = JRequest::getCmd('option');
        if($option == 'com_ajax' && $task == 'runAjax' && $format == 'raw') {
            $json = array(
                'count'=>$count
            );
            $json = json_encode($json);
            die($json);
        }
    }
    
    private function cancelAjax() {
        $this->unRegenAll();
        $this->resetOrdering();
        $json = array('ok'=>1);
        $json = json_encode($json);
        die($json);
    }
    
    private function checkKpl() {
        $file = JPATH_ADMINISTRATOR.'/components/com_kazaam/classes/kazaam.class.php';
        if(file_exists($file)) {
            require_once($file);
            return TRUE;
        }
        return FALSE;
    }
    
    private function checkTask() {
        
        $jinput = JFactory::getApplication()->input;
        $task = $jinput->get('task');
        $view = $jinput->get('view');
        $option = $jinput->get('option');
        $format = $jinput->get('format');
        $cid = (array) $jinput->get('cid', array(), 'ARRAY');
        $id = $jinput->get('id', 0);
        if(sizeof($cid)>0) $id = $cid[0];

        if($task === null && $format === null && (($option === 'com_plugins' && $this->getParam('regen') == '1')  || $option === 'com_kazaam')) return $this->doAjax();
        
        if($option === 'com_kazaam') {
            if($task === 'save' || $task === 'update') {
                $this->config = kazaamMenu::_getMenu($id);
                //ADD ID GRABBER!
                $this->regenAllCategories();
                $this->regenAllArticles();
                $this->saveParam('regen',1);
                return TRUE;
            }
        } else if($option === 'com_k2') {
            $triggers = array('save','apply','saveAndNew','publish','unpublish','trash','saveorder');
            if(!in_array($task,$triggers)) return FALSE;
            switch($view) {
                case 'item': $this->regenArticle($id,1);
                    break;
                case 'items': $this->regenAllArticles($cid,1);
                    break;
                case 'category': $this->regenCategory($id,1);
                    break;
                case 'categories': $this->regenAllCategories($cid,1);
                    break;
                default: return FALSE;
            }
            kazaamMenu::_regenAll();
            return TRUE;
        }
        if($option === 'com_ajax' && $task === 'cancelAjax') {
            $this->cancelAjax();
            $this->rebuildMenus();
            return TRUE;
        }
        
        $task = explode('.',$task);
        if(count($task) !== 2) return FALSE;
        $trigger = $task[0];
        
        if($trigger === 'plugin') {
            $formVals = $jinput->getArray(
                array(
                    'jform' => array(
                        'params' => array(
                            'regen' => 'int'
                        )
                    )
                )
            );
            if($formVals['jform']['params']['regen'] === 1) {
                $this->config = $this->getParams();
                $this->regenAllCategories();
                $this->regenAllArticles();
                return TRUE;
            } else {
                return FALSE;
            }
        }
        
        if(!in_array($trigger,$this->triggers)) return FALSE;
        if(!in_array($task[1],$this->actions)) return FALSE;
        
        $data = $jinput->getArray(array(
            'id' => 'int',
            'cid' => 'array'
        ));
        
        switch($trigger) {
            case 'category': $this->regenCategory($id,0);
                break;
            case 'categories': $this->regenAllCategories($cid,0);
                break;
            case 'article':
                if(!isset($_POST['id'])) $id = 0;
                $this->regenArticle($id,0);
                break;
            case 'articles': $this->regenAllArticles($cid,0);
                break;
            default: return FALSE;
                break;
        }
        if($this->checkKpl()) {
            kazaamMenu::_regenAll();
        } else {
            $this->saveParam('regen',1);
        }
        return TRUE;
    }
    
    private function getRegenTasks() {
        $db = JFactory::getDBO();
        $table = $db->quoteName($this->table);
        $query = "SELECT `cat`, `id`, `type` FROM {$table} ORDER BY `cat` DESC, `ordering`";
        $db->setQuery($query);
        $tasks = $db->loadObjectList();
        return $tasks;
    }
    
    private function regenTasks() {
        $this->config = $this->getParams();
        if((int) $this->getParam('regen') !== 1) return 0;
        $time = time();
        $this->createMenu();
        if((int) $this->getParam('cats') !== 1) $this->deleteCatItems($this->getParam('alias'));
        if((int) $this->getParam('arts') !== 1) $this->deleteArtItems($this->getParam('alias'));
        $tasks = $this->getRegenTasks();
        $count = count($tasks);
        if(count($tasks)>0) foreach($tasks as $t) {
            $this->regen($t->cat,$t->id,$t->type);
            $this->unRegen($t->cat,$t->id,$t->type);
            if($this->timeLimit($time)) {
                return --$count;
            }
        } else {
            $this->resetOrdering();
            $this->saveParam('regen',0);
            return $count;
        }
    }
    
    private function timeLimit($time=0,$count=0) {
        $now = time();
        if($now - $time >= 3) return TRUE;
        return FALSE;
    }
       
    private function regenKplTasks() {
        $time = time();
        $menus = (array) kazaamMenu::_getMenus();
        if(sizeof($menus)>0) foreach($menus as $m) {
            $this->config = $m;
            if((int) $this->getParam('regen') !== 1) continue;
            $this->createMenu();
            if((int) $this->getParam('cats') !== 1) $this->deleteCatItems($this->getParam('alias'));
            if((int) $this->getParam('arts') !== 1) $this->deleteArtItems($this->getParam('alias'));
            $tasks = $this->getRegenTasks();
            $count = count($tasks);
            if(count($tasks)>0) foreach($tasks as $n=>$t) {
                $this->regen($t->cat,$t->id,$t->type);
                $this->unRegen($t->cat,$t->id,$t->type);
                if($this->timeLimit($time)) {
                    return --$count;
                }
            } else {
                $this->resetOrdering();
                kazaamMenu::_saveParam('regen',0,$m->id);
                return $count;
            }
        }
        $this->unRegenAll();
        return 0;
    }
    
    private function resetOrdering() {
        $db = JFactory::getDBO();
        $table = $db->quoteName($this->table);
        $query = "ALTER TABLE {$table} AUTO_INCREMENT = 1";
        $db->setQuery($query);
        $db->query();
        $row = JTable::getInstance('menu');
        $row->rebuild();
    }
    
    private function regen($cat,$id) {
        if((int) $cat === 1) $this->saveCategory($id);
        else $this->saveArticle($id);
    }
    
    private function unRegen($cat,$id,$type) {
        $cat = (int)$cat;
        $id = (int)$id;
        $db = JFactory::getDBO();
        $table = $db->quoteName($this->table);
        $query = "DELETE FROM {$table} WHERE `cat` = '{$cat}' AND `id` = '{$id}' AND `type` = '{$type}'";
        $db->setQuery($query);
        $db->query();
    }
    
    private function unRegenAll() {
        $db = JFactory::getDBO();
        $table = $db->quoteName($this->table);
        $query = "DELETE FROM {$table}";
        $db->setQuery($query);
        $db->query();
        $this->saveParam('regen', 0);
    }

    private function deleteAllItems($alias = '') {
        $db = JFactory::getDBO();
        $alias = $db->quote($alias);
        $query = "DELETE FROM `#__menu` WHERE `menutype` = {$alias} AND `id` > '1'";
        $db->setQuery($query);
        $db->query();
    }
    
    private function deleteArtItems($alias = '') {
        $db = JFactory::getDBO();
        $alias = $db->quote($alias);
        $type = $this->getParam('type');
        if($type === '1') $query = "DELETE FROM `#__menu` WHERE `menutype` = {$alias} AND `id` > '1' AND `link` LIKE 'index.php?option=com_k2&view=item%'";
        else $query = "DELETE FROM `#__menu` WHERE `menutype` = {$alias} AND `id` > '1' AND `link` LIKE 'index.php?option=com_content&view=article%'";
        $db->setQuery($query);
        $db->query();
    }
    
    private function deleteCatItems($alias = '') {
        $db = JFactory::getDBO();
        $alias = $db->quote($alias);
        $type = $this->getParam('type');
        if($type === '1') $query = "DELETE FROM `#__menu` WHERE `menutype` = {$alias} AND `id` > '1' AND `link` LIKE 'index.php?option=com_k2%&layout=category%'";
        else $query = "DELETE FROM `#__menu` WHERE `menutype` = {$alias} AND `id` > '1' AND `link` LIKE 'index.php?option=com_content&view=category%'";
        $db->setQuery($query);
        $db->query();
    }

    private function deleteItem($id=0) {
        $id = (int)$id;
        $db = JFactory::getDBO();
        $query = "DELETE FROM `#__menu` WHERE `id` > '1' AND `id` = '{$id}'";
        $db->setQuery($query);
        $db->query();
    }
    
    private function getParam($name='') {
        if(isset($this->config->$name)) $param = $this->config->$name;
        else {
            $myparams = $this->getParams();
            if(!isset($myparams->$name)) return FALSE;
            $param = $myparams->$name;
        }
        return $param;
    }
    
    private function getParams() {
        $myparams = $this->myparams;
        $query = "SELECT `params` FROM `#__extensions` WHERE `type` = 'plugin' AND `folder` = 'system' AND `element` = 'kazaam' LIMIT 1";
        $db = JFactory::getDBO();
        $db->setQuery($query);
        $params = $db->loadResult();
        $params = json_decode($params);
        foreach($myparams as $name=>$value) {
            if(isset($params->$name)) 
                $myparams[$name] = $params->$name;
        }
        return (object) $myparams;
    }
    
    private function saveParam($name='',$value='') {

        if(!isset($this->myparams[$name])) return FALSE;
        
        $this->config = $this->getParams();
        
        if(is_array($value)) foreach($value as $n=>$v) {
            $value[$n] = addslashes($v);
        } else {
            $value = (strlen($value)>0) ? addslashes($value) : $this->getMyParam($name);
        }
        $this->config->$name = $value;
        
        $db = JFactory::getDBO();
        $myparams = json_encode($this->config);

        //BUILD THE QUERY
        $query = "UPDATE `#__extensions` SET `params` = '{$myparams}' WHERE `type` = 'plugin' AND `element` = 'kazaam' LIMIT 1";
		$db->setQuery($query);
		$db->query();
    }
    
    private function saveParams() {

        $myparams = $this->myparams;
        $this->config = $this->getParams();

        foreach($myparams as $name => $value) {
            if(isset($_POST[$name]) && strlen(trim($_POST[$name]))>0) $value = $_POST[$name];
            $this->config->$name = $value;
        }

        $db = JFactory::getDBO();
        $myparams = json_encode($this->config);
        
        //BUILD THE QUERY
        $query = "UPDATE `#__extensions` SET `params` = '{$myparams}' WHERE `type` = 'plugin' AND `element` = 'kazaam' LIMIT 1";
		$db->setQuery($query);
		$db->query();
    }
    
    private function regenCategory($id,$type='') {
        $id = (int)$id;
        if($type === '') $type = $this->getParam('type');
        if($id === 0) {
            if($type === '1') $query = "SELECT `id` FROM `#__k2_categories` ORDER BY `id` DESC LIMIT 1";
            else $query = "SELECT `id` FROM #__categories ORDER BY `id` DESC LIMIT 1";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $id = (int) $db->loadResult() + 1;
        }
        $db = JFactory::getDBO();
        $table = $db->quoteName($this->table);
        $query = "REPLACE INTO {$table} SET `cat` = '1', `id` = '{$id}', `type` = '{$type}'";
        $db->setQuery($query);
        $db->query();
    }
    
    private function regenArticle($id,$type='') {
        $id = (int)$id;
        if($type === '') $type = $this->getParam('type');
        $db = JFactory::getDBO();
        $table = $db->quoteName($this->table);
        if($id === 0) {
            if($type === '1') $query = "SELECT `id` FROM `#__k2_items` ORDER BY `id` DESC LIMIT 1";
            else $query = "SELECT `id` FROM `#__content` ORDER BY `id` DESC LIMIT 1";
            $db->setQuery($query); 
            $id = (int) $db->loadResult() + 1;
        }
        $query = "REPLACE INTO {$table} SET `cat` = '0', `id` = '{$id}', `type` = '{$type}'";
        $db->setQuery($query);
        $db->query();
    }

    private function regenAllCategories($cid = array(),$type=0) {
        
        if(empty($cid)) {
            $type = $this->getParam('type');
            if($type === '1') $query = "SELECT `id` FROM `#__k2_categories` ORDER BY `parent` ASC, `ordering` ASC";
            else $query = "SELECT `id` FROM `#__categories` WHERE `level` > '0' AND `extension` = 'com_content' ORDER BY `level` ASC, `lft` ASC";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $cats = $db->loadObjectList();
            foreach($cats as $c) $cid[] = $c->id;
        }
        if(count($cid)>0) {
            foreach($cid as $c) {
                $this->regenCategory($c);
            }
        }
    }

    private function regenAllArticles($cid = array(),$type=0) {
        
        if(empty($cid)) {
            $type = $this->getParam('type');
            if($type === '1') $query = "SELECT `id` FROM `#__k2_items` ORDER BY `id` DESC LIMIT 1";
            else $query = "SELECT `id` FROM `#__content` WHERE `state` >= '0' ORDER BY `ordering` ASC";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $cats = $db->loadObjectList();
            foreach($cats as $c) $cid[] = $c->id;
        }
        if(count($cid)>0) foreach($cid as $c) {
            $this->regenArticle($c);
        }
    }

    private function saveCategory($cat_id = 0) {
        if(!$this->saveCategoryItem($cat_id)) {
            $menu_id = $this->getCategoryItem($cat_id);
            if($menu_id !== FALSE) $this->deleteItem($menu_id);
        }
    }
    
    private function saveArticle($article_id = 0) {
        if(!$this->saveArticleItem($article_id)) {
            $menu_id = (int) $this->getArticleItem($article_id);
            if($menu_id > 0) $this->deleteItem($menu_id);
        }
    }
    
    private function getCategoryItem($cat_id = 0) {
        $menutype = $this->getParam('alias');
        $type = $this->getParam('type');
        $cat_id = (int)$cat_id;
        $db = JFactory::getDBO();
        if($type === '1') $link = "index.php?option=com_k2%&layout=category%id={$cat_id}";
        else $link = "index.php?option=com_content&view=category%id={$cat_id}";
        $query = "SELECT `id` FROM `#__menu` WHERE `menutype` = '{$menutype}' AND `link` LIKE '{$link}'";
        $db->setQuery($query);
        $menu = $db->loadObject();
        if(isset($menu->id)) return (int) $menu->id;
        return FALSE;
    }
    
    private function getArticleItem($article_id = 0) {
        $menutype = $this->getParam('alias');
        $type = $this->getParam('type');
        $article_id = (int)$article_id;
        $db = JFactory::getDBO();
        if($type === '1') $link = "index.php?option=com_k2&view=item&layout=item&id={$article_id}";
        else $link = "index.php?option=com_content&view=article%&id={$article_id}";
        $query = "SELECT `id` FROM `#__menu` WHERE `menutype` = '{$menutype}' AND `link` LIKE '{$link}'";
        $db->setQuery($query);
        $menu = $db->loadObject();
        if(isset($menu->id)) return (int) $menu->id;
        return 0;
    }
    
    private function getCpID($type=0) {
        switch($type) {
            case 0:
            default:
                $element = 'com_content';
                break;
            case 1:
                $element = 'com_k2';
                break;
        }
        $sql = "SELECT `extension_id` FROM `#__extensions` WHERE `element` = '{$element}' LIMIT 1";
        $db = JFactory::getDBO();
        $db->setQuery($sql);
        $id = (int) $db->loadResult();
        return $id;
    }

    private function saveCategoryItem($cat_id) {
        
        $cat_id = (int)$cat_id;
        if((int) $this->getParam('cats') !== 1) return FALSE;
        $categories = $this->getParam('categories');
        $type = $this->getParam('type');

        if(!in_array($cat_id,$categories)) {
            if((int) $this->getParam('subcats') !== 1) {
                return FALSE;
            }
            if($type === '1') $query = "SELECT `parent` FROM `#__k2_categories` WHERE `id` = '{$cat_id}'";
            else $query = "SELECT `parent_id` FROM `#__categories` WHERE `id` = '{$cat_id}'";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $parent = (int) $db->loadResult();
            if(!in_array($parent,$categories)) return FALSE;
            if($this->checkKpl()) {
                kazaamCatMap::_saveCat($this->getParam('id'),$cat_id);
            } else {
                $categories[] = $cat_id;
                $this->saveParam('categories',$categories);
            }
        }
        
        if($type === '1') {
            $query = "SELECT `id`, `name` as `title`, `alias`, `published`, `access`, `parent` as `parent_id`, `language` FROM `#__k2_categories` WHERE `id` = '{$cat_id}'";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $category = $db->loadObject();
            if(!isset($category->id)) return FALSE;
            $menu_id = $this->getCategoryItem($cat_id);
            $link = "index.php?option=com_k2&view=itemlist&layout=category&task=category&id={$category->id}";
        } else {
            $query = "SELECT `id`, `parent_id`, `title`, `alias`, `published`, `access`, `language` FROM `#__categories` WHERE `level` > '0' AND `extension` = 'com_content' AND `id` = '{$cat_id}'";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $category = $db->loadObject();
            if(!isset($category->id)) return FALSE;
            $menu_id = $this->getCategoryItem($cat_id);
            $layout = $this->getParam('category_layout');
            $layout = ($layout !== 'list') ? "&layout={$layout}" : "";
            $link = "index.php?option=com_content&view=category{$layout}&id={$category->id}";
        }
        if(!$menu_id) $menu_id = 0;
        $component_id = $this->getCpID($type);
        $parent_id = (int) $this->getCategoryItem($category->parent_id);
        if($parent_id < 1) $parent_id = 1;
        $alias = $this->checkAlias($category->alias, $menu_id);
        $menutype = $this->getParam('alias');
        $published = $category->published;
        $menu_details = $this->getMenuDetails($menu_id);
        $data = array(
            'id' => $menu_id,
            'title' => $category->title,
            'alias' => $alias,
            'note' => $menu_details->note,
            'link' => $link,
            'menutype' => $menutype,
            'type' => 'component',
            'published' => $category->published,
            'parent_id' => $parent_id,
            'component_id' => $component_id,
            'browserNav' => 0,
            'access' => $category->access,
            'template_style_id' => $menu_details->template_style_id,
            'home' => $menu_details->home,
            'language' => $category->language,
            'lft' => self::$_order++,
            'rgt' => self::$_order++,
        );
        $params = $this->getParam('params');
        if(!is_array($params)) $params = (object) json_decode($params);
        $menu_details->params = (object) json_decode($menu_details->params);

        if(sizeof($menu_details->params) > 0) foreach($menu_details->params as $name=>$value) {
            if($value === '') continue;
            else if(!isset($params->$name) || $params->$name === '') $params->$name = $value;
        }
        if($type === '1') $params->categories = array($category->id);
        if(count($params) > 0) $data['params'] = json_encode($params);
        
        // Get a db connection.
        $db = JFactory::getDbo();
        
        $query = $db->quoteName('#__menu');
        $query .= " SET ";
        foreach($data as $field=>$value) {
            if($field !== 'id') $query .= ',';
            $field = $db->quoteName($field);
            $value = $db->quote($value);
            $query .= "{$field} = {$value}";
        }
        
        if($menu_id > 0) $query = "UPDATE ".$query." WHERE `id` = '{$menu_id}'";
        else $query = "INSERT INTO ".$query;
        
        $db->setQuery($query);
        $success = $db->execute();

/*
        $row = JTable::getInstance('menu');
        $row->setLocation($parent_id, 'last-child');
        
        if (!$row->bind($data)) {
            die($row->getError());
        }
        
        if (!$row->check()) {
            die($row->getError());
        }
        if (!$row->store()) {
            die($row->getError());
        }
		if (!$row->rebuildPath($row->id)) {
			$this->setError($row->getError());
		}
*/
        return TRUE;
    }
    
    private function saveArticleItem($article_id) {
        
        $article_id = (int)$article_id;
        
        if((int) $this->getParam('arts') !== 1) return FALSE;
        $type = $this->getParam('type');
        
        if($type === '1') {
            $query = "SELECT `id`, `title`, `alias`, `published` as `state`, `catid`, `access`, `language` FROM `#__k2_items` WHERE `id` = '{$article_id}'";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $article = $db->loadObject();
            if(!isset($article->id)) return FALSE;
            $categories = $this->getParam('categories');
            if(!in_array($article->catid,$categories)) return FALSE;
            $menu_id = $this->getArticleItem($article->id);
            $link = "index.php?option=com_k2&view=item&layout=item&id={$article->id}";
        } else {
            $query = "SELECT `id`, `title`, `alias`, `state`, `catid`, `access`, `language` FROM `#__content` WHERE `id` = '{$article_id}'";
            $db = JFactory::getDBO();
            $db->setQuery($query);
            $article = $db->loadObject();
            if(!isset($article->id)) return FALSE;
            $categories = $this->getParam('categories');
            if(!in_array($article->catid,$categories)) return FALSE;
            $menu_id = $this->getArticleItem($article->id);
            $link = 'index.php?option=com_content&view=article&id='.$article->id;
        }
        $component_id = $this->getCpID($type);
        $parent_id = (int) $this->getCategoryItem($article->catid);
        if($parent_id < 1) $parent_id = 1;
        $alias = $this->checkAlias($article->alias, $menu_id);
        $menutype = $this->getParam('alias');
        $menu_details = $this->getMenuDetails($menu_id);
        $data = array(
            'id' => $menu_id,
            'title' => $article->title,
            'alias' => $alias,
            'note' => $menu_details->note,
            'link' => $link,
            'menutype' => $menutype,
            'type' => 'component',
            'published' => $article->state,
            'parent_id' => $parent_id,
            'component_id' => $component_id,
            'browserNav' => 0,
            'access' => $article->access,
            'template_style_id' => $menu_details->template_style_id,
            'home' => $menu_details->home,
            'language' => $article->language,
            'lft' => self::$_order++,
            'rgt' => self::$_order++,
        );
        
        $params = json_decode($this->getParam('params'));
        $menu_details->params = json_decode($menu_details->params);
        if($menu_details->params) foreach($menu_details->params as $name=>$value) {
            if($value === '') continue;
            else if(!isset($params->$name) || $params->$name === '') $params->$name = $value;
        }
        if($params) $data['params'] = json_encode($params);
        else $data['params'] = json_encode((object) array());
        
        
        // Get a db connection.
        $db = JFactory::getDbo();
        
        $query = $db->quoteName('#__menu');
        $query .= " SET ";
        foreach($data as $field=>$value) {
            if($field !== 'id') $query .= ',';
            $field = $db->quoteName($field);
            $value = $db->quote($value);
            $query .= "{$field} = {$value}";
        }
        
        if($menu_id > 0) $query = "UPDATE ".$query." WHERE `id` = '{$menu_id}'";
        else $query = "INSERT INTO ".$query;
        $db->setQuery($query);
        $db->execute();
        
        /*
        
        $row = JTable::getInstance('menu');
        $row->setLocation($parent_id, 'last-child');
        
        if (!$row->bind($data)) {
            die($row->getError());
        }
        
        if (!$row->check()) {
            die($row->getError());
        }
        
        if (!$row->store()) {
            die($row->getError());
        }
        
		if (!$row->rebuildPath($row->id)) {
			$this->setError($row->getError());
		}
        $row->rebuild();
*/
        return TRUE;
    }

    private function createMenu() {
        
        $alias = $this->getParam('alias');
        
        $db = JFactory::getDBO();
        $query = "SELECT `id` FROM `#__menu_types` WHERE `menutype` = '{$alias}' LIMIT 1";
        $db->setQuery($query);
        $id = (int) $db->loadResult();
        if($id < 1) {
            $title = $this->getParam('name');
            $language = $this->getParam('language');
            $access = $this->getParam('access');
            $status = $this->getParam('status');
            $query = "INSERT INTO ".$db->quoteName('#__menu_types')
                ." SET "
                .$db->quoteName('menutype')
                ." = ".$db->quote($alias)
                .",".$db->quoteName('title')
                ."=".$db->quote($title);
            $db->setQuery($query);
            $db->query();
            
            $data = array(
                'id' => 0,
                'title' => $title,
                'note' => '',
                'module' => 'mod_menu',
                'showtitle' => '1',
                'published' => $status,
                'publish_up' => '',
                'publish_down' => '',
                'client_id' => '0',
                'position' => '',
                'access' => $access,
                'ordering' => '1',
                'language' => $language,
                'assignment' => '0',
                'params' => array (
                    'menutype' => $alias
                )
            );
            $row = JTable::getInstance('module');
            if (!$row->bind($data)) {
                $this->setError($row->getError());
                return false;
            }
            if (!$row->check()) {
                $this->setError($row->getError());
                return false;
            }
            if (!$row->store()) {
                $this->setError($row->getError());
                return false;
            }
        }
        return TRUE;
    }

    private function checkAlias($alias, $id) {

        $db = JFactory::getDBO();
        
        //QUICK LOOP TO CHECK IF ALIAS EXISTS - MAYBE REPLACE WITH DO...WHILE
        $alias = trim($alias, " \t\n\r\0\x0B-");
        $origalias = $alias;                
        $i = 0;
        do {
            if($i++ > 0) $alias = $origalias.'-'.$i;
            $query = "SELECT ".$db->quoteName('id')." FROM #__menu WHERE ".$db->quoteName('alias')." = ".$db->quote($alias)." AND ".$db->quoteName('id')." != ".$db->quote($id)." LIMIT 1";
            $db->setQuery($query);
            $row = $db->loadColumn();
        }
        while (isset($row[0]));
        return $alias;
    }
    
    private function getMenuDetails($menu_id = 0) {
        $menu_id = (int)$menu_id;
        $menu = array('note' => '', 'home' => '', 'template_style_id' => '', 'params' => '');
        if($menu_id === 0) return (object) $menu;
        $db = JFactory::getDBO();
        $query = "SELECT `note`, `home`, `template_style_id`, `params` FROM `#__menu` WHERE `id` = '{$menu_id}' LIMIT 1";
        $db->setQuery($query);
        $res = $db->loadObject();
        if(sizeof($res)>0) return $res;
        return (object) $menu;
    }
}