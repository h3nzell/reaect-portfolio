DROP TABLE IF EXISTS `#__kazaam_regen`;

CREATE TABLE IF NOT EXISTS `#__kazaam_regen` (
  `cat` tinyint(4) NOT NULL,
  `id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `ordering` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ordering`),
  UNIQUE KEY `cat` (`cat`,`id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

